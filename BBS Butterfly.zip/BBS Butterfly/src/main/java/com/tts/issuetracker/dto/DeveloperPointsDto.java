package com.tts.issuetracker.dto;


public class DeveloperPointsDto {
	private Integer developerId;
	private Integer points;
	
	public Integer getDeveloperId() {
		return developerId;
	}
	public void setDeveloperId(Integer developerId) {
		this.developerId = developerId;
	}
	public Integer getPoints() {
		return points;
	}
	public void setPoints(Integer points) {
		this.points = points;
	}
}
